<?php
include 'includes/head.php';
include 'includes/header.php';
include 'includes/navbar.php';
?>

<div id="content">
    <?php include 'pages/home.php'; ?>
</div>

<?php include 'includes/footer.php'; ?>
