<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">Dashboard</h1>
    <p>Welcome to SB Admin 2!</p>
</div>
